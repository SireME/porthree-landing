export default function Footer(){
    return(
        <div className="text-center h-10 border-t py-10">
            <p className="font-bold">Porthree 2023 | All Rights Reserved</p>
        </div>
    )
}
